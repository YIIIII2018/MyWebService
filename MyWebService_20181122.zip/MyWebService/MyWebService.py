#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
学号：2018282110414
姓名：易晓博
'''

"""
坑爹点：
代码里async被自动标位特殊颜色，因为在Python3.7里async变成了关键字，关键字是不能做变量名的，只要把这个名字改成任意不是关键字的词就好了。

"""
import logging
from mainFun import mainFun
from wsgiref.simple_server import make_server
from spyne import Integer, Unicode, Array, ComplexModel, Iterable, String
from spyne import Application
from spyne import rpc
from spyne import ServiceBase
from spyne import Iterable, Integer, Unicode
from spyne.protocol.soap import Soap11
from spyne.server.wsgi import WsgiApplication



class MyInfo(ComplexModel):
   ip = Unicode
   endPlace = Unicode
   info = Unicode

class MyService(ServiceBase):
    @rpc(Array(MyInfo), _returns=Unicode )
    def say_hello(self, myInfos):
       for myInfo in myInfos:
          #print("123"+mainFun(myInfo.ip,myInfo.endPlace).allinfo)
          myInfo.info = mainFun(myInfo.ip,myInfo.endPlace).allinfo
          return myInfo.info


soap_app = Application([MyService], 'spyne.examples.hello.soap',
                       in_protocol=Soap11(validator='lxml'),
                       out_protocol=Soap11())

wsgi_app = WsgiApplication(soap_app)

if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG)
    logging.getLogger('spyne.protocol.xml').setLevel(logging.DEBUG)

    logging.info("listening to http://127.0.0.1:8000")
    logging.info("wsdl is at: http://localhost:8000/?wsdl")

    server = make_server('127.0.0.1', 8000, wsgi_app)
    server.serve_forever()