#做到一半，邮箱因发送大量邮件被拒收，计划流产

import smtplib
from email.mime.text import MIMEText

msgtype = 'html'
mailto_list = ["852744912@qq.com"]
mail_host = "smtp.sina.com"
mail_user = "whu2018282110414@sina.com"
mail_pwd = "yxb2018282110414"

me = "<" + mail_user + ">"
msg = MIMEText("<h1>Hello</h1>", _subtype=msgtype, _charset='utf8')
msg['Subject'] = 'theme'
msg['From'] = me
msg['To'] = ";".join(mailto_list)

s = smtplib.SMTP()
s.connect(mail_host)  # 连接smtp服务器
s.login(mail_user, mail_pwd)  # 登陆服务器
s.sendmail(me,mailto_list, msg.as_string())  # 发送邮件
s.close()