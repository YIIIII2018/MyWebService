#做到一半，邮箱因发送大量邮件被拒收，计划流产
#!/usr/bin/env python

import os
from time import sleep
from tkinter import *

class Register(object):
    def __init__(self, initdir=None):
        self.top = Tk()
        self.label = Label(self.top,
            text='Register By WebService')
        self.label.pack()


def main():
    d = Register()
    mainloop()

if __name__ == '__main__':
    main()
