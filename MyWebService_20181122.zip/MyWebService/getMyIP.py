#!/usr/bin/python
# -*- coding:utf8 -*-
'''
学号：2018282110414
姓名：易晓博
'''


import requests
import re
import time
import urllib.request
from xml.dom.minidom import parseString

#获得本机IP
#因为很多服务之后随时可能停止，因此获取本机公网IP的地址需要定时更新维护
def get_ip():
    response = requests.get("http://"+str(time.localtime().tm_year)+".ip138.com/ic.asp")
    ip = re.search(r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}",response.content.decode(errors='ignore')).group(0)
    return ip



def getAddressByIP(ip):
    page = urllib.request.urlopen(
        "http://ws.webxml.com.cn/WebServices/IpAddressSearchWebService.asmx/getCountryCityByIp?theIpAddress=%s" % ip)
    lines = page.readlines()
    page.close()
    document = ""
    for line in lines:
        document = document + line.decode('utf-8')
        #print(line.decode('utf-8'))
        #调试可用，去除xml数据
    dom = parseString(document)
    strings = dom.getElementsByTagName("string")[1].childNodes[0].data
    #print(strings)
    #调试可用，过滤到不需要的数据，只把数据取出来
    myaddr=re.findall(r"省(.+?)市", strings)
    #print(myaddr[0])
    #调试可用，过滤到不要的文字，只把城市名取出来
    return myaddr[0]