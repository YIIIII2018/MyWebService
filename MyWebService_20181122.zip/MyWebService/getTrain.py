# -*- coding: utf-8 -*-
'''
学号：2018282110414
姓名：易晓博
'''

'''
这里涉及到urlopen含中文字符集的问题，python27和python37解决方法还不一样
python37麻烦一点，笔记如下：
对于一个url连接例如”www.abc.cn/name=北京”这样一个链接，如果直接用urlopen读取会报错：
解决办法就是使用urllib.parse.quote()解析中文部分。
url=”www.abc.cn/name=”+urllib.parse.quote(“北京”)
也可以使用safe参数指定不解析的字符
url=urllib.parse.quote(“www.abc.cn/name=北京”,safe=’/:?=.’)
指定’/:?=.’这些符号不转换
'''

import sys
import time
from xml.dom.minidom import parseString
import urllib.request



def displayTrainInfo(tmpFrom,tmpTo):
    tmpInfo=getAllTrainByAddr(tmpFrom,tmpTo)
    for i in tmpInfo:
        print(i)


#根据出发地和目的地获取所有的火车列次
def getAllTrainByAddr(myfrom,myto):
    url ="http://ws.webxml.com.cn/WebServices/TrainTimeWebService.asmx/getStationAndTimeByStationName?StartStation="\
         +urllib.parse.quote(myfrom)\
         +"&ArriveStation="+urllib.parse.quote(myto)+"&UserID="+urllib.parse.quote("")
    #print(url)
    page = urllib.request.urlopen(url)
    lines = page.readlines()
    page.close()
    document = ""
    for line in lines:
        #print(line.decode('utf-8'))
        document = document + line.decode('utf-8')
    dom = parseString(document)
    trainInfo = dom.getElementsByTagName("TimeTable")#所有列次的信息
    #调用时间过滤
    timeDom=getTrainByTime(trainInfo)
    return timeDom
    #返回一个符合当前时间的火车列次的list

#根据当前的时间过滤到无效的火车列次
def getTrainByTime(tmpInfo):
    #符合条件的最后火车list
    trainList=[]
    #获取当前时间
    lt = time.localtime()
    #print(lt)
    nowTime=time.strftime("%H%M%S", lt)
    for i in tmpInfo:
        #print(i.getElementsByTagName("FirstStation")[0].childNodes[0].data)
        isNone=i.getElementsByTagName("FirstStation")[0].childNodes[0].data
        if(isNone=="数据没有被发现"):
            return ['没有符合条件的火车列次']
        trainTime1 = str(i.getElementsByTagName("StartTime")[0].childNodes[0].data)
        trainTime2 = "2018-12-10 "+ trainTime1
        trainTime3  = time.strptime(trainTime2, "%Y-%m-%d %H:%M:%S")
        trainTime = time.strftime("%H%M%S", trainTime3)
        #print(trainTime)
        #print(int(trainTime)>int(nowTime))
        singleTrainInfo=[]
        #如果火车的发车时间比现在的时间晚，才列出来
        #测试时间，正式的请把010000换成nowTime
        if(int(trainTime)>int("010000")):
            tmpTrainCode = i.getElementsByTagName("TrainCode")[0].childNodes[0].data
            tmpFirstStation = i.getElementsByTagName("FirstStation")[0].childNodes[0].data
            tmpLastStation = i.getElementsByTagName("LastStation")[0].childNodes[0].data
            tmpStartStation = i.getElementsByTagName("StartStation")[0].childNodes[0].data
            tmpStartTime = i.getElementsByTagName("StartTime")[0].childNodes[0].data
            tmpArriveStation = i.getElementsByTagName("ArriveStation")[0].childNodes[0].data
            tmpArriveTime = i.getElementsByTagName("ArriveTime")[0].childNodes[0].data
            singleTrainInfo.append("车次："+tmpTrainCode)
            singleTrainInfo.append("始发站："+tmpFirstStation)
            singleTrainInfo.append("终点站："+tmpLastStation)
            singleTrainInfo.append("出发点："+tmpStartStation)
            singleTrainInfo.append("出发时间："+tmpStartTime)
            singleTrainInfo.append("目的地："+tmpArriveStation)
            singleTrainInfo.append("到达时间："+tmpArriveTime)
        trainList.append(singleTrainInfo)
    return trainList



