'''
学号：2018282110414
姓名：易晓博
'''



def getMyDestination():
    fs=open("D:\PycharmProjects\MyWebService\cityid.txt","r")
    lines=fs.readlines()
    allcity = []
    for i in lines:
        #print(i)
        tmpcity = i[10:12]
        #print(tmpcity)
        allcity.append(tmpcity)
    fs.close()
    return  allcity

