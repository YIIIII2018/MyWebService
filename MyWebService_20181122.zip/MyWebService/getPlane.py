'''
学号：2018282110414
姓名：易晓博
'''



import time
from xml.dom.minidom import parseString
import urllib.request


def displayPlaneInfo(tmpFrom,tmpTo):
    tmpInfo=getAllPlaneByAddr(tmpFrom,tmpTo)
    for i in tmpInfo:
        print(i)


#根据出发地和目的地获取所有的飞机航班
def getAllPlaneByAddr(myfrom,myto):
    url ="http://ws.webxml.com.cn/webservices/DomesticAirline.asmx/getDomesticAirlinesTime?startCity="\
         +urllib.parse.quote(myfrom)+"&lastCity="+urllib.parse.quote(myto)\
         +"&theDate="+urllib.parse.quote("")+"&UserID="+urllib.parse.quote("")
    #print(url)
    page = urllib.request.urlopen(url)
    lines = page.readlines()
    page.close()
    document = ""
    for line in lines:
        #print(line.decode('utf-8'))
        document = document + line.decode('utf-8')
    dom = parseString(document)
    planeInfo = dom.getElementsByTagName("AirlinesTime")#所有航班的信息
    #调用时间过滤
    timeDom=getPlaneByTime(planeInfo)
    return timeDom
    #返回一个符合当前时间的飞机航班的list

#根据当前的时间过滤到无效的飞机航班
def getPlaneByTime(tmpInfo):
    #符合条件的最后飞机list
    planeList=[]
    #获取当前时间
    lt = time.localtime()
    #print(lt)
    nowTime=time.strftime("%H%M%S", lt)
    for i in tmpInfo:
        #print(i.getElementsByTagName("FirstStation")[0].childNodes[0].data)
        isNone=i.getElementsByTagName("Company")[0].childNodes[0].data
        if(isNone=="出发或抵达的城市不被支持"):
            return ['没有符合条件的飞机航班']
        planeTime1 = str(i.getElementsByTagName("StartTime")[0].childNodes[0].data)
        planeTime2 = "2018-12-10 "+ planeTime1+":00"
        planeTime3  = time.strptime(planeTime2, "%Y-%m-%d %H:%M:%S")
        planeTime = time.strftime("%H%M%S", planeTime3)

        singlePlaneInfo=[]
        #如果飞机的起飞时间比现在的时间晚，才列出来
        #测试时间，正式的请把010000换成nowTime
        if(int(planeTime)>int("010000")):
            tmpCompany = i.getElementsByTagName("Company")[0].childNodes[0].data
            tmpAirlineCode = i.getElementsByTagName("AirlineCode")[0].childNodes[0].data
            tmpStartDrome = i.getElementsByTagName("StartDrome")[0].childNodes[0].data
            tmpArriveDrome = i.getElementsByTagName("ArriveDrome")[0].childNodes[0].data
            tmpStartTime = i.getElementsByTagName("StartTime")[0].childNodes[0].data
            tmpArriveTime = i.getElementsByTagName("ArriveTime")[0].childNodes[0].data
            singlePlaneInfo.append("航空公司："+tmpCompany)
            singlePlaneInfo.append("航班号："+tmpAirlineCode)
            singlePlaneInfo.append("出发机场："+tmpStartDrome)
            singlePlaneInfo.append("到达机场："+tmpArriveDrome)
            singlePlaneInfo.append("出发时间："+tmpStartTime)
            singlePlaneInfo.append("到达时间："+tmpArriveTime)
        planeList.append(singlePlaneInfo)
    return planeList