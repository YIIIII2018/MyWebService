#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
学号：2018282110414
姓名：易晓博
'''

from suds.client import Client  # 导入suds.client 模块下的Client类
from MyWebService import MyInfo

wsdl_url = "http://localhost:8000/?wsdl"


if __name__ == '__main__':
    client = Client(wsdl_url)  # 创建一个webservice接口对象
    # my_test(wsdl_url, '27.17.80.101', '北京')
    # 测试，其实IP读取本机公网IP，目的地由用户输入，时间系统取当前北京时间
    myInfo = {}
    myInfo['ip'] = '27.17.80.101'
    myInfo['endPlace'] = '北京'

    myInfos = client.factory.create('MyInfoArray')
    myInfos.MyInfo.append(myInfo)

    result = client.service.say_hello(myInfos)
    print(result)