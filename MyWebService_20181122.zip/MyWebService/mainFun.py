# -*- coding: utf-8 -*-
'''
学号：2018282110414
姓名：易晓博
'''

import getMyIP
import getDestination
import getTrain
import getPlane
import random

class mainFun():
    info1=""
    info2 = ""
    info3 = ""
    info4 = ""
    allinfo = ""


    def __init__(self,ip,endPlace):
        #根据IP获取本地地址
        tmpAddr=getMyIP.getAddressByIP(ip)
        print("出发点："+tmpAddr)
        self.info1="出发点："+tmpAddr
        print("============================")

        #随机从全国城市库随机挑一个目的地
        tmp_allcity=getDestination.getMyDestination()
        #print(len(tmp_allcity))
        #全国2574个市县
        random_city=randomDestination=random.randint(0,2573)
        tmpcity=tmp_allcity[random_city]
        print("目的地："+endPlace)
        self.info2 = "目的地："+endPlace
        print("============================")

        #测试火车列次信息
        #tmpAddr出发点
        #tmpcity目的地
        #随机选目的地，大部分查不出飞机火车的信息，所以测试过程强制北京
        #getTrain.displayTrainInfo(tmpAddr,tmpcity)
        #正常请使用这一语句
        getTrain.displayTrainInfo(tmpAddr,endPlace)
        self.info3 = str(getTrain.getAllTrainByAddr(tmpAddr,endPlace))
        print("============================")

        #测试飞机航班信息
        #tmpAddr出发点
        #tmpcity目的地
        #随机选目的地，大部分查不出飞机火车的信息，所以测试过程强制北京
        #getPlane.displayPlaneInfo(tmpAddr,tmpcity)
        #正常请使用这一语句
        getPlane.displayPlaneInfo(tmpAddr,endPlace)
        self.info4 = str(getPlane.getAllPlaneByAddr(tmpAddr, endPlace))
        print("============================")

        self.allinfo=self.info1+","+self.info2+","+self.info3+","+self.info4


#test1=mainFun('27.17.80.101', '北京').allinfo
#print(test1)